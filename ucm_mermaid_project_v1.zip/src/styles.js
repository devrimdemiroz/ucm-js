const getStyles = (options) =>
  `
  .path-line {
    fill: none;
    stroke: #000000;
    stroke-width: 2px;
    stroke-linecap: round;
    stroke-linejoin: round;
  }

  .component-rect {
    fill: rgba(255, 255, 255, 0.1); 
    stroke: #FF0000; /* Red Outline */
    stroke-width: 2px;
    rx: 0;
    ry: 0;
    cursor: pointer;
  }

  .component-rect:hover {
    stroke-width: 3px;
    fill: rgba(255, 0, 0, 0.05);
  }
  
  .component-rect.selected {
      stroke: #FF0000;
      stroke-width: 4px;
      stroke-dasharray: 4,2;
  }

  .component-text {
    font-family: 'Arial', sans-serif;
    font-size: 14px;
    fill: #000000;
    font-weight: bold;
    text-anchor: middle;
  }

  .responsibility-mark {
    stroke: #000000;
    stroke-width: 2px;
    fill: none;
  }

  .responsibility-text {
    font-family: 'Arial', sans-serif;
    font-size: 12px;
    fill: #000000;
    text-anchor: middle;
  }
  
  .start-node {
     fill: #000000;
     stroke: none;
  }
  
  .end-node {
      fill: #000000;
      stroke: none;
  }
`;

export default getStyles;
