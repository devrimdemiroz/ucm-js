# UCM Mermaid Extension

A Mermaid.js extension for rendering **Use Case Maps (UCM)** using a "London Tube Map" inspired visualization.

## Overview
This project implements the [ITU-T Z.151](https://www.itu.int/rec/T-REC-Z.151) Use Case Map standard as a declarative diagram diagram. It aligns with the "Path-Centric" philosophy where the system is modeled as an abstract network graph of Components (containers) and Responsibilities (nodes) connected by Paths (edges).

## Features
-   **Declarative Syntax**: Simple DSL to define components and paths.
-   **Tube Map Visuals**: High-contrast Black & White styling.
-   **Live Editor**: Browser-based editor with real-time updates.
-   **Interactivity**: Click-to-expand components.

## Getting Started

### Prerequisites
-   Python 3 (for running the local server) or any static file server.
-   Modern Web Browser.

### Installation
Clone this repository (or copy the files):
```bash
/src
  /db.js
  /parser.js
  /renderer.js
  /styles.js
  /ucmDiagram.js
index.html
```

### Running the Editor
1.  Open your terminal in the project directory.
2.  Start the local server:
    ```bash
    python3 -m http.server 8000
    ```
3.  Open your browser to [http://localhost:8000/index.html](http://localhost:8000/index.html).

## Syntax Guide

The UCM syntax is line-based and declarative.

```mermaid
ucm
component "Component Name"
path "Path Name" start "StartNode" end "EndNode"
responsibility "Responsibility Name"
```

### Example
```text
ucm
component "Authentication System"
component "Database"
path "Login Flow" 
    start "User" 
    end "Database" 
    responsibility "Check Creds"
```

## Architecture
-   **`ucmDiagram.js`**: Main entry point. Registers the diagram with Mermaid (or handles manual loading).
-   **`parser.js`**: Parses the text into a `UcmDb` object.
-   **`db.js`**: The Graph Store. Holds normalized lists of nodes (components/responsibilities) and edges (paths).
-   **`renderer.js`**: D3.js based renderer. Draws the SVG based on the DB state.
-   **`styles.js`**: Returns CSS strings for the Diagram.

## References
-   **Standards**: ITU-T Z.151, jUCMNav.
-   **Philosophy**: "Everything is a Node/Edge".
